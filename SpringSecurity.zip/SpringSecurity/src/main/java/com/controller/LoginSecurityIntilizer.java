package com.controller;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class LoginSecurityIntilizer extends AbstractSecurityWebApplicationInitializer {

	public LoginSecurityIntilizer() {
		super(LoginSecurityConfig.class);
		
		
	}
	
	
	
	
	

}
